/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 133377
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "2"
#define R_MINOR  "9.1"
#define R_STATUS ""
#define R_YEAR   "2009"
#define R_MONTH  "06"
#define R_DAY    "26"
#define R_SVN_REVISION "48839"
#define R_FILEVERSION    2,91,48839,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
