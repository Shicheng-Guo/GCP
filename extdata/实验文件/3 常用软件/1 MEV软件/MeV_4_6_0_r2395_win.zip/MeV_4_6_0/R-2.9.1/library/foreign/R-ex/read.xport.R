### Name: read.xport
### Title: Read a SAS XPORT Format Library
### Aliases: read.xport
### Keywords: file

### ** Examples

## Not run: 
##D read.xport("transport")
## End(Not run)



