### Name: checkUsage
### Title: Check R Code for Possible Problems
### Aliases: checkUsage checkUsageEnv checkUsagePackage
### Keywords: programming

### ** Examples

checkUsage(checkUsage)
checkUsagePackage("codetools",all=TRUE)
## Not run: checkUsagePackage("base",suppressLocal=TRUE)



