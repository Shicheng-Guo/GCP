### Name: read.mtp
### Title: Read a Minitab Portable Worksheet
### Aliases: read.mtp
### Keywords: file

### ** Examples

## Not run: 
##D read.mtp("ex1-10.mtp")
## End(Not run)



