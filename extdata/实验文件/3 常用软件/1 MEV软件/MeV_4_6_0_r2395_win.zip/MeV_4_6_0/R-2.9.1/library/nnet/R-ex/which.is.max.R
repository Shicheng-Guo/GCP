### Name: which.is.max
### Title: Find Maximum Position in Vector
### Aliases: which.is.max
### Keywords: utilities

### ** Examples

## Not run: 
##D pred <- predict(nnet, test)
##D table(true, apply(pred,1,which.is.max))
## End(Not run)


