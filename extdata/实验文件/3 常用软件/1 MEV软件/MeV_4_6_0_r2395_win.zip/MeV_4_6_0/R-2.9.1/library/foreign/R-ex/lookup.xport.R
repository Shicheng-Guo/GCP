### Name: lookup.xport
### Title: Lookup Information on a SAS XPORT Format Library
### Aliases: lookup.xport
### Keywords: file

### ** Examples

## Not run: 
##D lookup.xport("transport")
## End(Not run)



