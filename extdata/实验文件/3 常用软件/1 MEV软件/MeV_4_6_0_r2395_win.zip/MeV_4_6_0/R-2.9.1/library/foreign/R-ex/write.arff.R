### Name: write.arff
### Title: Write Data into ARFF Files
### Aliases: write.arff
### Keywords: print file

### ** Examples

write.arff(iris, file = "")



