### Name: read.dbf
### Title: Read a DBF File
### Aliases: read.dbf
### Keywords: file

### ** Examples

x <- read.dbf(system.file("files/sids.dbf", package="foreign")[1])
str(x)
summary(x)



