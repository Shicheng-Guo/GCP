### Name: showTree
### Title: Print Lisp-Style Representation of R Expression
### Aliases: showTree
### Keywords: programming

### ** Examples

showTree(quote(-3))
showTree(quote("x"<-1))
showTree(quote("f"(x)))



